#!/bin/bash
set -euo pipefail

# ----------- ARG PARSING -----------
REMOTE_PORT=""
REMOTE_HOST="localhost"
DO_CLEANUP=0
DO_XMP=1
XMP_VENV=""
XMP_SCRIPT=""
SSH_OPTS=""
UI_HOME_OVERRIDE=""
SYNC_ID=""
PROGRESS_FILE=""

# Ensure new files default to 0644, dirs to 0755 (group-readable)
umask 022

usage() {
  echo "Usage: $0 -p <ssh-port> [--host <ip-or-name>] [--UI_HOME <path>] [--cleanup] [--no-xmp] [--venv <path>] [--xmp-script <path>] [--ssh-opts \"<flags>\"] [--sync-id <id>]"
  exit 1
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -p)           REMOTE_PORT="${2:-}"; shift 2 ;;
    --host)       REMOTE_HOST="${2:-}"; shift 2 ;;
    --UI_HOME)    UI_HOME_OVERRIDE="${2:-}"; shift 2 ;;
    --cleanup)    DO_CLEANUP=1; shift ;;
    --no-xmp)     DO_XMP=0; shift ;;
    --venv)       XMP_VENV="${2:-}"; shift 2 ;;
    --xmp-script) XMP_SCRIPT="${2:-}"; shift 2 ;;
    --ssh-opts)   SSH_OPTS="${2:-}"; shift 2 ;;
    --sync-id)    SYNC_ID="${2:-}"; shift 2 ;;
    *)            usage ;;
  esac
done

if [ -z "$REMOTE_PORT" ]; then
  echo "❌ Port not specified."; usage
fi

# Set up progress tracking
if [[ -n "$SYNC_ID" ]]; then
  PROGRESS_FILE="/tmp/sync_progress_${SYNC_ID}.json"
  # Initialize progress file
  cat > "$PROGRESS_FILE" << EOF
{
  "sync_id": "$SYNC_ID",
  "status": "starting",
  "current_stage": "initialization",
  "progress_percent": 0,
  "total_folders": 0,
  "completed_folders": 0,
  "current_folder": "",
  "messages": [],
  "start_time": "$(date -Iseconds)",
  "last_update": "$(date -Iseconds)"
}
EOF
fi

# Progress update function
update_progress() {
  if [[ -n "$PROGRESS_FILE" && -f "$PROGRESS_FILE" ]]; then
    local stage="$1"
    local percent="$2"
    local message="$3"
    local current_folder="${4:-}"
    
    # Create a temporary file to update progress atomically
    local temp_file="${PROGRESS_FILE}.tmp"
    
    # Read current progress, update it, and write back
    python3 -c "
import json
import sys
from datetime import datetime

try:
    with open('$PROGRESS_FILE', 'r') as f:
        data = json.load(f)
except:
    data = {
        'sync_id': '$SYNC_ID',
        'status': 'running',
        'messages': [],
        'start_time': datetime.now().isoformat()
    }

data['current_stage'] = '$stage'
data['progress_percent'] = $percent
data['last_update'] = datetime.now().isoformat()
data['status'] = 'running'

if '$current_folder':
    data['current_folder'] = '$current_folder'

if '$message':
    data['messages'].append({
        'timestamp': datetime.now().isoformat(),
        'message': '$message'
    })
    # Keep only last 20 messages
    data['messages'] = data['messages'][-20:]

with open('$temp_file', 'w') as f:
    json.dump(data, f, indent=2)
" 2>/dev/null || true

    # Atomically replace the progress file
    if [[ -f "$temp_file" ]]; then
      mv "$temp_file" "$PROGRESS_FILE"
    fi
  fi
}

# ----------- CONFIGURATION -----------
REMOTE_USER=root
SSH_KEY=/root/.ssh/id_ed25519
LOCAL_BASE=/media
FOLDERS=("txt2img-grids" "txt2img-images" "img2img-grids" "img2img-images" "WAN" "extras-images")

# Defaults for XMP tool (can be overridden by flags)
DEFAULT_VENV="$(dirname "$0")/.venv"
DEFAULT_XMP_SCRIPT="$(dirname "$0")/xmp_tool.py"
XMP_VENV="${XMP_VENV:-$DEFAULT_VENV}"
XMP_SCRIPT="${XMP_SCRIPT:-$DEFAULT_XMP_SCRIPT}"
VENV_PY="$XMP_VENV/bin/python"

# Safer rsync flags for QNAP/eCryptfs:
# - Do NOT preserve perms/owner/group/times; those caused "Bad address (14)" in the past
RSYNC_FLAGS=(-rltD --delete --no-perms --no-owner --no-group --omit-dir-times --no-times --info=stats2 --human-readable)
if rsync --help 2>&1 | grep -q -- '--mkpath'; then
  RSYNC_FLAGS+=(--mkpath)
fi

# SSH base
SSH_BASE=(ssh -p "$REMOTE_PORT" -i "$SSH_KEY" -o UserKnownHostsFile=/root/.ssh/known_hosts -o IdentitiesOnly=yes -o StrictHostKeyChecking=yes)
if [[ -n "$SSH_OPTS" ]]; then SSH_BASE+=($SSH_OPTS); fi
SSH_DEST="$REMOTE_USER@$REMOTE_HOST"
SSH_CMD=("${SSH_BASE[@]}" "$SSH_DEST")

# ----------- HELPERS -----------
# Post-pass normalize: make files 0644 and dirs 0755 without tripping eCryptfs quirks.
normalize_permissions() {
  local path="$1"

  # First try chmod quietly; if it fails, we fallback to install(1) trick for files.
  # Normalize directories (chmod tends to be less problematic for dirs).
  find "$path" -type d ! -perm -0755 -exec chmod 0755 {} + 2>/dev/null || true

  # Try chmod for files; if any fail, we repair those specific ones via install -m
  # Gather files that still aren't 0644
  mapfile -d '' not_ok < <(find "$path" -type f ! -perm -0644 -print0 2>/dev/null || true)
  if ((${#not_ok[@]})); then
    # Attempt chmod; failures will remain not 0644 and get fixed below
    chmod -f 0644 "${not_ok[@]}" 2>/dev/null || true
  fi

  # Find any files still not 0644 and fix by copy-rename (atomic)
  find "$path" -type f ! -perm -0644 -print0 2>/dev/null | while IFS= read -r -d '' f; do
    tmp="${f}.tmp.$$"
    # Preserve content/ownership by current user; set mode explicitly
    # install is from coreutils (present on Debian/Ubuntu images)
    if install -m 0644 -T -- "$f" "$tmp"; then
      mv -f -- "$tmp" "$f" || rm -f -- "$tmp"
    else
      rm -f -- "$tmp" 2>/dev/null || true
    fi
  done
}

# XMP tool
run_xmp_for_dir() {
  local dir="$1"
  [[ "$DO_XMP" -eq 1 ]] || return 0
  [[ -x "$VENV_PY" ]] || { echo "⚠️  XMP skipped ($dir): venv python not found at $VENV_PY"; return 0; }
  [[ -f "$XMP_SCRIPT" ]] || { echo "⚠️  XMP skipped ($dir): script not found at $XMP_SCRIPT"; return 0; }

  if [[ "$DO_XMP" -ne 1 ]]; then
    return 0
  fi
  
  # Determine which Python to use - prefer venv, fallback to system python
  local python_exe=""
  if [ -x "$VENV_PY" ]; then
    python_exe="$VENV_PY"
  elif command -v python3 >/dev/null 2>&1; then
    python_exe="python3"
  elif command -v python >/dev/null 2>&1; then
    python_exe="python"
  else
    echo "⚠️  XMP skipped ($dir): no python executable found"
    return 0
  fi
  
  if [ ! -f "$XMP_SCRIPT" ]; then
    echo "⚠️  XMP skipped ($dir): script not found at $XMP_SCRIPT"
    return 0
  fi

  # Count PNG files
  local png_count
  png_count=$(find "$dir" -type f -iname '*.png' | wc -l)
  [[ "$png_count" -gt 0 ]] || { echo "📝 XMP: no PNGs in $dir"; return 0; }

  if find "$dir" -type f -iname '*.png' -print0 \
      | xargs -0 -r -n 50 "$python_exe" "$XMP_SCRIPT" >/dev/null 2>&1; then
    echo "📝 XMP: processed $png_count PNG(s) in $dir"
  else
    echo "⚠️  XMP: errors while processing $png_count PNG(s) in $dir"
  fi
}

# -------------------------------------

echo "🔗 Remote: $SSH_DEST  (port $REMOTE_PORT)"
[[ -n "$SSH_OPTS" ]] && echo "   SSH extra opts: $SSH_OPTS"

update_progress "ssh_setup" 5 "Setting up SSH connection"

# Start ssh-agent and add key
eval "$(ssh-agent -s)"
ssh-add "$SSH_KEY" || { echo "❌ Failed to add SSH key. Exiting."; exit 1; }

update_progress "remote_discovery" 10 "Discovering remote UI_HOME"

# ----------- GET UI_HOME FROM REMOTE (or override) -----------
if [[ -n "$UI_HOME_OVERRIDE" ]]; then
  UI_HOME="$UI_HOME_OVERRIDE"
  echo "📍 Using UI_HOME override: $UI_HOME"
  update_progress "remote_discovery" 15 "Using UI_HOME override: $UI_HOME"
else
  UI_HOME="$("${SSH_CMD[@]}" 'source /etc/environment 2>/dev/null || true; echo "${UI_HOME:-}"' || true)"
  if [ -z "$UI_HOME" ]; then
    echo "❌ Failed to retrieve UI_HOME from remote environment. Use --UI_HOME to specify it manually."
    update_progress "error" 0 "Failed to retrieve UI_HOME from remote"
    exit 1
  fi
  echo "📍 Retrieved UI_HOME from remote: $UI_HOME"
  update_progress "remote_discovery" 15 "Retrieved UI_HOME: $UI_HOME"
fi

# Detect outputs dir
OUTPUT_DIR="$("${SSH_CMD[@]}" "if [ -d \"$UI_HOME/output\" ]; then echo output; elif [ -d \"$UI_HOME/outputs\" ]; then echo outputs; else echo ''; fi" || true)"
if [ -z "$OUTPUT_DIR" ]; then
  echo "❌ Could not find 'output' or 'outputs' directory under $UI_HOME on the remote."
  update_progress "error" 0 "Could not find output directory"
  exit 1
fi

REMOTE_BASE="$UI_HOME/$OUTPUT_DIR"
echo "📁 Using remote output path: $REMOTE_BASE"
update_progress "folder_discovery" 20 "Found remote output path: $REMOTE_BASE"

# ----------- SYNC FOLDERS -----------
# Count total folders to sync
total_folders=0
for folder in "${FOLDERS[@]}"; do
  REMOTE_DIR_EXISTS="$("${SSH_CMD[@]}" "[ -d \"$REMOTE_BASE/$folder\" ] && echo yes || echo no" || true)"
  if [[ "$REMOTE_DIR_EXISTS" == "yes" ]]; then
    remote_subdirs="$("${SSH_CMD[@]}" "find \"$REMOTE_BASE/$folder\" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' 2>/dev/null || true")"
    if [ -n "$remote_subdirs" ]; then
      total_folders=$((total_folders + $(echo "$remote_subdirs" | wc -l)))
    fi
  fi
done

# Update progress file with total folders
if [[ -n "$PROGRESS_FILE" && -f "$PROGRESS_FILE" ]]; then
  python3 -c "
import json
try:
    with open('$PROGRESS_FILE', 'r') as f:
        data = json.load(f)
    data['total_folders'] = $total_folders
    with open('$PROGRESS_FILE', 'w') as f:
        json.dump(data, f, indent=2)
except:
    pass
" 2>/dev/null || true
fi

update_progress "sync_folders" 25 "Starting folder sync (found $total_folders folders)"

completed_folders=0
for folder in "${FOLDERS[@]}"; do
  echo "📁 Checking: $folder"
  update_progress "sync_folders" $((25 + (completed_folders * 60 / total_folders))) "Checking folder: $folder" "$folder"

  REMOTE_DIR_EXISTS="$("${SSH_CMD[@]}" "[ -d \"$REMOTE_BASE/$folder\" ] && echo yes || echo no" || true)"
  if [[ "$REMOTE_DIR_EXISTS" != "yes" ]]; then
    echo "⚠️  Remote folder missing: $REMOTE_BASE/$folder — skipping."
    update_progress "sync_folders" $((25 + (completed_folders * 60 / total_folders))) "Remote folder missing: $folder" "$folder"
    continue
  fi

  remote_subdirs="$("${SSH_CMD[@]}" "find \"$REMOTE_BASE/$folder\" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' 2>/dev/null || true")"
  if [ -z "$remote_subdirs" ]; then
    echo "⚠️  No subfolders found in $folder — skipping."
    update_progress "sync_folders" $((25 + (completed_folders * 60 / total_folders))) "No subfolders in: $folder" "$folder"
    continue
  fi

  for subdir in $remote_subdirs; do
    remote_path="$REMOTE_BASE/$folder/$subdir/"
    local_path="$LOCAL_BASE/$folder/$subdir"

    if [ ! -d "$local_path" ]; then
      echo "📁 Creating missing local folder: $folder/$subdir"
      mkdir -p "$local_path"
    else
      echo "✅ Local folder exists: $folder/$subdir"
    fi

    echo "🔄 Syncing files"
    update_progress "sync_folders" $((25 + (completed_folders * 60 / total_folders))) "Syncing: $folder/$subdir" "$folder"
    
    RSYNC_SSH=("${SSH_BASE[@]}")

    rsync "${RSYNC_FLAGS[@]}" -e "$(printf '%q ' "${RSYNC_SSH[@]}")" \
      "$SSH_DEST:$remote_path" "$local_path/"

    # Normalize permissions so SMB users can read
    echo "🛡  Normalizing permissions under: $local_path"
    normalize_permissions "$local_path"

    # XMP sidecar generation
    run_xmp_for_dir "$local_path"
    
    completed_folders=$((completed_folders + 1))
    
    # Update progress file with completed folders
    if [[ -n "$PROGRESS_FILE" && -f "$PROGRESS_FILE" ]]; then
      python3 -c "
import json
try:
    with open('$PROGRESS_FILE', 'r') as f:
        data = json.load(f)
    data['completed_folders'] = $completed_folders
    with open('$PROGRESS_FILE', 'w') as f:
        json.dump(data, f, indent=2)
except:
    pass
" 2>/dev/null || true
    fi
  done
done

# ----------- OPTIONAL REMOTE CLEANUP -----------
if [[ "$DO_CLEANUP" -eq 1 ]]; then
  update_progress "cleanup" 90 "Starting remote cleanup"
  CUTOFF_DATE="$(date -d '2 days ago' +%F)"
  echo "🧹 Cleanup enabled. Deleting remote dated folders older than $CUTOFF_DATE ..."
  for folder in "${FOLDERS[@]}"; do
    REMOTE_DIR_EXISTS="$("${SSH_CMD[@]}" "[ -d \"$REMOTE_BASE/$folder\" ] && echo yes || echo no" || true)"
    if [[ "$REMOTE_DIR_EXISTS" != "yes" ]]; then
      echo "   • Skipping $folder (remote folder not found)"
      continue
    fi
    echo "   • Scanning $folder ..."
    "${SSH_CMD[@]}" "
      set -eu
      cutoff='$CUTOFF_DATE'
      base=\"$REMOTE_BASE/$folder\"
      if [ -d \"\$base\" ]; then
        find \"\$base\" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' 2>/dev/null \
          | grep -E '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' \
          | while IFS= read -r d; do
              if [ \"\$d\" \< \"\$cutoff\" ]; then
                echo \"🗑 Deleting \$base/\$d\"
                rm -rf \"\$base/\$d\"
              fi
            done
      fi
    " || true
  done
  echo "✅ Cleanup complete."
  update_progress "cleanup" 95 "Remote cleanup completed"
fi

# ----------- COMPLETION -----------
update_progress "complete" 100 "Sync completed successfully"

# ----------- CLEANUP -----------
# Mark sync as completed in progress file
if [[ -n "$PROGRESS_FILE" && -f "$PROGRESS_FILE" ]]; then
  python3 -c "
import json
from datetime import datetime
try:
    with open('$PROGRESS_FILE', 'r') as f:
        data = json.load(f)
    data['status'] = 'completed'
    data['end_time'] = datetime.now().isoformat()
    data['current_stage'] = 'complete'
    data['progress_percent'] = 100
    with open('$PROGRESS_FILE', 'w') as f:
        json.dump(data, f, indent=2)
except:
    pass
" 2>/dev/null || true
fi

ssh-agent -k
